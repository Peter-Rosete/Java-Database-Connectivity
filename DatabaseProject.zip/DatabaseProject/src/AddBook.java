import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class AddBook {
    //Add a book
    //GLOBAL VARIABLES
    String[] searchCriteria = {"book_isbn","book_title","book_author_id","book_type",
    "book_price","book_year","book_publisher","book_genre","book_language"};

    //Make a method for the input of the books and determine the results from that
    public void addBookInput(Connection con) throws SQLException{

        System.out.println("\n---FETCHING THE SEARCH RESULT---");
        Scanner scan = new Scanner(System.in);
        String[] input = new String [9];
        
        System.out.println("Please enter ISBN (can also type NULL)");
        input[0] = "0000001";//scan.nextLine();

        //Get the author name 
        System.out.println("Please enter the title (can also type NULL)");
        input[1] = "TestTitle";//scan.nextLine();
       
        //Get the ISBN 
        System.out.println("Please enter author_id (can also type NULL)");
        input[2] = "1";//scan.nextLine();
        
        //Get the number of results
        System.out.println("Please enter type(can also type NULL)");
        input[3] = "Test";//scan.nextLine();

        //Get the title name 
        System.out.println("Please enter price(can also type NULL)");
        input[4] = "10.00";

        //Get the title name 
        System.out.println("Please enter year(can also type NULL)");
        input[5] = "2OOO";

        //Get the title name 
        System.out.println("Please enter publisher(can also type NULL)");
        input[6] = "TestPublisher";
        
        //Get the title name 
        System.out.println("Please enter genre(can also type NULL)");
        input[7] = "TestGenre";

        //Get the title name 
        System.out.println("Please enter langauge(can also type NULL)");
        input[8] = "English";

        //scan.nextLine();

        addBook(con, input);
    }

    //Insert a book
    public void addBook(Connection con, String [] input) throws SQLException{
        System.out.println("\n---INPUTTING A NEW BOOK---");
        String queryTest = "insert into library_system.book values("+ input[0];
        for(int i = 1; i < 9; i++){
            queryTest = queryTest.concat(", '" + input[i] + "'");
        }
        queryTest = queryTest.concat(");");
        //String queryWorking = "insert into vendor values(36901, 'TestName', 'TestContact', '100', '000-0000', 'NA', 'S');";
        
        System.out.println(queryTest);
       // System.out.println(queryWorking);
        
       // if (queryWorking == queryTest)
       //     System.out.println("IT WORKS");
       // else 
        //    System.out.println("IT DOESN'T WORK");
        Statement statement = con.createStatement();
        statement.executeUpdate(queryTest);
    }

    // METHOD 3 - PRINT RESULT
    static void printResults(ResultSet result){
        try{  
            //Testing that you get the data
            while(result.next()){
                String UniversityData = "";
                for(int i = 1; i <= 6; i++){
                    UniversityData += result.getString(i) + ":";
                }
                System.out.println(UniversityData);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
