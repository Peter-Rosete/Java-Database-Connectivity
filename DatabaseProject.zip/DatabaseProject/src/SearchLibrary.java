import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class SearchLibrary {
    //Return a list of all the libraries - todo
    public void  returnAll(Connection con) throws SQLException{
        System.out.println("\n---PRINTING ALL PERSON SEARCH RESULTS---");
        String query = "select * from customer";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    //return a specific Library - specific Library - todo
    static void returnLibrary(Connection con) throws SQLException{
        System.out.println("\n---PRINTING CONDITIONAL PERSON SEARCH RESULTS---");
        String query = "SELECT * FROM abc.invoice where CUS_CODE = 10014;";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    // METHOD 3 - PRINT RESULT
    static void printResults(ResultSet result){
        try{  
            //Testing that you get the data
            while(result.next()){
                String UniversityData = "";
                for(int i = 1; i <= 6; i++){
                    UniversityData += result.getString(i) + ":";
                }
                System.out.println(UniversityData);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
