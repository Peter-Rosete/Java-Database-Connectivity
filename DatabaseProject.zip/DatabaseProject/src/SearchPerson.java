import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class SearchPerson {

    //Global Variables
    

    public void searchInput(Connection con) throws SQLException{

        System.out.println("\n---FETCHING THE SEARCH RESULT---");
        Scanner scan = new Scanner(System.in);
        String[] input = new String [5];
        //Get the title name 
        System.out.println("What is the ID number of the patron (can also type NULL)");
        input[0] = scan.nextLine();

        //Get the author name 
        System.out.println("What is the first name of the patron (can also type NULL)");
        input[1] = scan.nextLine();
       
        //Get the ISBN 
        System.out.println("What is the last name of the patron (can also type NULL)");
        input[2] = scan.nextLine();
        
        //Get the number of results
        System.out.println("how many results did you want to load(can also type NULL)");
        input[3] = scan.nextLine();

        returnPerson(con, input);
    }
    //METHOD 1 
    public void  returnAll(Connection con) throws SQLException{
        System.out.println("\n---PRINTING ALL PERSON SEARCH RESULTS---");
        String query = "select * from customer";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    //METHOD 2 - specific person
    static void returnPerson(Connection con, String [] input) throws SQLException{
        System.out.println("\n---PRINTING PERSON SEARCH RESULTS---");
        String[] searchCriteria = {"patron_id","patron_fname","patron_lname"}; 
        //FOR adding to the where clause
        String whereClause = " WHERE ";
        for(int i = 0; i < 3; i++){
            if(input[i] != "NULL"){
                if(input[i].matches(".*\\d"))
                    whereClause = whereClause.concat(searchCriteria[i] + " = " + input[i]);
                else
                    whereClause = whereClause.concat(searchCriteria[i] + " = " + "'" + input[i] + "'");
            }
            if((i+1 < 3) && (input[i + 1] != "NULL") && (i > 0))
                whereClause = whereClause.concat(" AND ");
            
        }
        String query = "SELECT * FROM library_system.patron";
        if(whereClause.length() > 7)
            query = query.concat(whereClause + ";");
        System.out.println(query);
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    // METHOD 3 - PRINT RESULT
    static void printResults(ResultSet result){
        try{  
            //Testing that you get the data
            while(result.next()){
                String UniversityData = "";
                for(int i = 1; i <= 6; i++){
                    UniversityData += result.getString(i) + ":";
                }
                System.out.println(UniversityData);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
