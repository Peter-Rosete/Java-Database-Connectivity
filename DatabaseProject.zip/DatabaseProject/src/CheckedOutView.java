import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class CheckedOutView {

     //Make a method for the input of the books and determine the results from that
     public void searchInput(Connection con) throws SQLException{
 
         System.out.println("\n---PRINTING LIST OF PATRON FEES---");
        
        String query = "SELECT * FROM library_system.patron_checked_out;";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
     }
 
     // METHOD 3 - PRINT RESULT
     static void printResults(ResultSet result){
         try{  
             //Testing that you get the data
             while(result.next()){
                 String UniversityData = "";
                 for(int i = 1; i <= 8; i++){
                     UniversityData += result.getString(i) + ":";
                 }
                 System.out.println(UniversityData);
             }
         }catch(SQLException e){
             e.printStackTrace();
         }
     }
}