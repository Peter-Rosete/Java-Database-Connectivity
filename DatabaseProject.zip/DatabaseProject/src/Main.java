import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class Main {
    public static void main(String[] args)  throws SQLException {

        //Call the classes
        SearchBook searchbook = new SearchBook();
        SearchPerson searchPerson = new SearchPerson();
        AddBook addBook = new AddBook();
        CheckoutBook checkoutBook = new CheckoutBook();
        ReturnBook returnBook = new ReturnBook();
        RenewBook renewBook = new RenewBook();
        PayFees payfee = new PayFees();
        
        //Views
        CheckedOutView checkedOutView = new CheckedOutView();
        Update_View update_View = new Update_View();
        FeesOwedView feesOwedView = new FeesOwedView();
        FeesOwedDetail feesOwedDetail = new FeesOwedDetail();

        //Info we are going to need
        String url = "jdbc:mysql://localhost:3306/library_system";
        String uname = "";
        String password = "";
        Connection con = DriverManager.getConnection(url, uname, password);
        Statement statement = con.createStatement();
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Please Enter a command\n[SEARCH_BOOK, SEARCH_PERSON, REMOVE_BOOK , ADD_BOOK, CHECKOUT_BOOK, RETURN_BOOK, RENEW_BOOK, PAY_FEE, UPDATE_VIEW, CHECKED_OUT_VIEW, FEES_OWED, FEES_OWED_DETAIL]\n");
        String txt = "FEES_OWED_DETAIL";
        switch(txt){
            case "SEARCH_BOOK":
                System.out.println("---You chose the SEARCH_BOOK COMMAND---");
                searchbook.searchInput(con);
                break;
            //WORKS
            case "SEARCH_PERSON":
                System.out.println("---You chose the SEARCH_PERSON COMMAND---");
                searchPerson.searchInput(con);
                break;
            //WORKS
            case "ADD_BOOK":
                System.out.println("---You chose the ADD_BOOK COMMAND---");
                addBook.addBookInput(con);
                break;
            case "CHECKOUT_BOOK":
                System.out.println("---You are checking out a book---");
                checkoutBook.searchInput(con);
                break;
            case "RETURN_BOOK":
                System.out.println("---You are returning a book you checked out---");
                returnBook.searchInput(con);
                break;
            case "RENEW_BOOK":
                System.out.println("---You are renewing a book---");
                renewBook.searchInput(con);
                break;
            case "PAY_FEE":
                System.out.println("---You are paying a fee---");
                payfee.searchInput(con);
                break;
            case "UPDATE_VIEW":
                System.out.println("---You are updating the fee list---");
                update_View.searchInput(con);
            break;
            //Views 
            case "CHECKED_OUT_VIEW":
                System.out.println("---LIST OF CHECKED OUT BOOKS---");
                checkedOutView.searchInput(con);
                break;
            case "FEES_OWED":
                System.out.println("---LIST OF FEES---");
                feesOwedView.searchInput(con);
                break;
            case "FEES_OWED_DETAIL":
                System.out.println("---LIST OF DETAILS FEES---");
                feesOwedDetail.searchInput(con);
                break;
            default:
                System.out.println("ENTERED AN INVALID COMMAND");
        }
    }
}
