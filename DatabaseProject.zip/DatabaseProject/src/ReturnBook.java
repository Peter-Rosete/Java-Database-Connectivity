import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class ReturnBook {
    //GLOBAL VARIABLES - here
    String[] searchCriteria = {"patron_num","isbn","copy","return_date","bookstate"};

    //Make a method for the input of the books and determine the results from that
    public void searchInput(Connection con) throws SQLException{

        System.out.println("\n---RETURN A BOOK---");
        Scanner scan = new Scanner(System.in);
        String[] input = new String [5];
        
        //Get the patron_num
        System.out.println("What is the patron_num (can also type NULL)");
        input[0] = scan.nextLine();

        //Get the ISBN
        System.out.println("What is the isbn (can also type NULL)");
        input[1] = scan.nextLine();
       
        //Get the Copy
        System.out.println("What is the copy(can also type NULL)");
        input[2] = scan.nextLine();
        
        //Get the number of results
        //System.out.println("What is the checkout date)");
        input[3] = "2020-02-01 00:00:00";

        //Get the book state
        System.out.println("What state is the book in");
        input[4] = scan.nextLine();
        returnBook(con, input);
    }
    //Testings the entire table for BOOK
    public void  returnAll(Connection con) throws SQLException{
        //todo
        System.out.println("\n---PRINTING ALL THE CHECKED OUT BOOKS---");
        String query = "select * from library_system.checked_out";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    //Method 2: Search a Specfic book
    public void  returnBook(Connection con, String [] input) throws SQLException{
        System.out.println("\n---RETURNING A OUT A BOOK---");
        
        //FOR adding to the where clause
        String query = "CALL return_book(";
        for(int i = 0; i < 3; i++){
            query = query.concat(input[i] + ",");
        }
        query = query.concat("'" + input[3] + "','" + input[4] +"');");
        System.out.println(query);
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        //printResults(result);
        returnAll(con);
    }

    // METHOD 3 - PRINT RESULT
    static void printResults(ResultSet result){
        try{  
            //Testing that you get the data
            while(result.next()){
                String UniversityData = "";
                for(int i = 1; i <= 6; i++){
                    UniversityData += result.getString(i) + ":";
                }
                System.out.println(UniversityData);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
