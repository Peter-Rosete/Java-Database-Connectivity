
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class PayFees {
    //GLOBAL VARIABLES
    String[] searchCriteria = {"patron_num","input_amount"};

    //Make a method for the input of the books and determine the results from that
    public void searchInput(Connection con) throws SQLException{

        System.out.println("\n---PAYING A FEE---");
        Scanner scan = new Scanner(System.in);
        String[] input = new String [2];
        
        //Get the patron_num
        System.out.println("What is the patron_num (can also type NULL)");
        input[0] = scan.nextLine();

        //Get the ISBN
        System.out.println("What is the input amount (can also type NULL)");
        input[1] = scan.nextLine();

        payfee(con, input);
    }
    //Testings the entire table for BOOK
    public void  returnAll(Connection con) throws SQLException{
        System.out.println("\n---PRINTING ALL OF THE BOOKS THAT HAVE BEEN CHECKED OUT---");
        String query = "select * from library_system.fee";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    //Method 2: Search a Specfic book
    public void  payfee(Connection con, String [] input) throws SQLException{
        System.out.println("\n---Paying fee---");
        
        //FOR adding to the where clause
        String query = "CALL pay_fee(";
        for(int i = 0; i < 2; i++){
            if (i < 1)
                query = query.concat(input[i] + ",");
            else
                query = query.concat(input[i]);
        }
        query = query.concat(");");

        System.out.println(query);
        //Statement statement = con.createStatement();
        //statement.executeQuery(query);
        returnAll(con);
    }

    // METHOD 3 - PRINT RESULT
    static void printResults(ResultSet result){
        try{  
            //Testing that you get the data
            while(result.next()){
                String UniversityData = "";
                for(int i = 1; i <= 7; i++){
                    UniversityData += result.getString(i) + ":";
                }
                System.out.println(UniversityData);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
