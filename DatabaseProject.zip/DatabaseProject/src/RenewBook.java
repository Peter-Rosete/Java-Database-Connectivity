import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class RenewBook {
    //GLOBAL VARIABLES
    String[] searchCriteria = {"patron_num","isbn","copy","check_out_date"};

    //Make a method for the input of the books and determine the results from that
    public void searchInput(Connection con) throws SQLException{

        Scanner scan = new Scanner(System.in);
        String[] input = new String [4];
        
        //Get the patron_num
        System.out.println("What is the patron_num (can also type NULL)");
        input[0] = scan.nextLine();

        //Get the ISBN
        System.out.println("What is the isbn (can also type NULL)");
        input[1] = scan.nextLine();
       
        //Get the Copy
        System.out.println("What is the copy(can also type NULL)");
        input[2] = scan.nextLine();
        
        //Get the number of results
        //System.out.println("What is the checkout date)");
        input[3] = "2020-01-01 00:00:00";

        renewBook(con, input);
    }
    //Testings the entire table for BOOK
    public void  returnAll(Connection con) throws SQLException{
        System.out.println("\n---PRINTING ALL OF THE BOOKS THAT HAVE BEEN CHECKED OUT---");
        String query = "select * from library_system.checked_out";
        Statement statement = con.createStatement();
        ResultSet result = statement.executeQuery(query);
        printResults(result);
    }

    //Method 2: Search a Specfic book
    public void  renewBook(Connection con, String [] input) throws SQLException{
        System.out.println("\n---RENEW A CHECKED OUT BOOK---");
        
        //FOR adding to the where clause
        String query = "CALL renew_book(";
        for(int i = 0; i < 3; i++){
            if (i < 2)
                query = query.concat(input[i] + ",");
            else
                query = query.concat(input[i]);
        }
        query = query.concat(");");

        System.out.println(query);
        returnAll(con);
    }

    // METHOD 3 - PRINT RESULT
    static void printResults(ResultSet result){
        try{  
            //Testing that you get the data
            while(result.next()){
                String UniversityData = "";
                for(int i = 1; i <= 6; i++){
                    UniversityData += result.getString(i) + ":";
                }
                System.out.println(UniversityData);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
